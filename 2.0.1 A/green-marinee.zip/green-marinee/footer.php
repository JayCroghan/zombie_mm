<!-- begin footer -->
<hr />
	<div id="footer">
	<p>The Green Marin&eacute;e template by <a href="http://e-lusion.com" title="Ian Main - e-lusion.com">Ian Main</a> - Built for <a href="http://wordpress.org" title="Wordpress - As lovely as your Mum!">Wordpress 1.5</a></p>
		<div class="extras">
			<ul>
				<li><a href="feed:<?php bloginfo('rss2_url'); ?>" title="Subscribe to RSS feed">RSS</a></li>
				<li><a href="feed:<?php bloginfo('comments_rss2_url'); ?>" title="Subscribe to Comments RSS feed">Comments RSS</a></li>
				<li><a href="feed:<?php bloginfo('atom_url'); ?>" title="Subscribe to Atom feed">Atom</a></li>
				<li><a href="http://wordpress.org/" title="Powered by the lovely WordPress">WP</a></li>
			</ul>
		</div>
	</div>
	</div>
	</div>
	</div>
	</div>
</div>
<?php do_action('wp_footer'); ?>
</body>
</html>