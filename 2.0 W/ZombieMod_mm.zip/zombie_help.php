<HTML>
<HEAD>
	<title>ZombieMod::Help</title>
</HEAD>
<BODY bgcolor="#000000">
<CENTER>
<IMG SRC="zombie_help.gif" BORDER="0">
</CENTER>
</BODY>
</HTML>