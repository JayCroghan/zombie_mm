/* ======== props_mm ========
* Copyright (C) 2004-2005 Metamod:Source Development Team
* No warranties of any kind
*
* License: zlib/libpng
*
* Author(s): David "BAILOPAN" Anderson
* ============================
*/
#include "server_class.h"
#include "ZombiePlugin.h"
#include "cvars.h"
#include "myutils.h"

#include "mapentities.h"

ZombieAccessor					g_Accessor;
extern ConVar					zombie_enabled;
extern ConVar					zombie_health;
extern CTeam					*teamCT;
extern CTeam					*teamT;
extern ArrayLengthSendProxyFn	TeamCount;
extern PlayerInfo_t				g_Players[65];
extern int						g_RestrictT[CSW_MAX];
extern int						g_RestrictCT[CSW_MAX];
extern int						g_RestrictW[CSW_MAX];

ConVar zombie_version( "zombie_version", ZOMBIE_VERSION, FCVAR_REPLICATED | FCVAR_SPONLY | FCVAR_NOTIFY, "ZombieMod Plugin version");

bool ZombieAccessor::RegisterConCommandBase(ConCommandBase *pVar)
{
	return META_REGCVAR( pVar );
}

CON_COMMAND( zombie_loadsettings, "Loads the ZombieMod configuration file.")
{
	m_Engine->ServerCommand( "exec zombiemod/zombiemod.cfg\n" );
}

CON_COMMAND(zombie_dump, "Dumps the map entity list to a file")
{
	DumpMapEnts();
}

CON_COMMAND( zombie_check, "" )
{
	g_ZombiePlugin.ShowZomb();
}

CON_COMMAND( zombie_comm, "<name> - Executes command on a player." )
{
	if ( !zombie_enabled.GetBool() )
	{
		META_LOG( g_PLAPI, "%s: Zombie mode is not currently enabled\n", m_Engine->Cmd_Argv(0) );
		return;
	}
	CPlayerMatchList matches(m_Engine->Cmd_Argv(1), true);
	if ( matches.Count() < 1 ) 
	{
		META_LOG( g_PLAPI, "%s: Unable to find any living players that match %s\n", m_Engine->Cmd_Argv(0), m_Engine->Cmd_Argv(1));
		//print(pEdict, "%s: Unable to find any living players that match %s\n", g_ZombiePlugin.m_Engine->Cmd_Argv(0), g_ZombiePlugin.m_Engine->Cmd_Argv(1));
		return;
	}
	for ( int x = 0; x < matches.Count(); x++ )
	{
		edict_t* cEnt = matches.GetMatch(x); //->GetUnknown()->GetBaseEntity();
		int iPlayer = m_Engine->IndexOfEdict( cEnt );
		//m_Engine->ClientCommand( cEnt, m_Engine->Cmd_Argv(2) );
		//g_ZombiePlugin.ShowMOTD( iPlayer, "Welcome to ZombieMod", "Welcome to ZombieMod ;)", TYPE_TEXT, "toggle cl_restrict_server_commands 0" );
		g_ZombiePlugin.SetProtection( iPlayer, !g_Players[iPlayer].bProtected, false );
	}
	return;
}


CON_COMMAND( zombie_player, "<name> - Turns player into a zombie if zombie mode is on." )
{
	if ( !zombie_enabled.GetBool() )
	{
		META_LOG( g_PLAPI, "%s: Zombie mode is not currently enabled\n", m_Engine->Cmd_Argv(0) );
		return;
	}
	CPlayerMatchList matches(m_Engine->Cmd_Argv(1), true);
	if ( matches.Count() < 1 ) 
	{
		META_LOG( g_PLAPI, "%s: Unable to find any living players that match %s\n", m_Engine->Cmd_Argv(0), m_Engine->Cmd_Argv(1));
		//print(pEdict, "%s: Unable to find any living players that match %s\n", g_ZombiePlugin.m_Engine->Cmd_Argv(0), g_ZombiePlugin.m_Engine->Cmd_Argv(1));
		return;
	}
	for ( int x = 0; x < matches.Count(); x++ )
	{
		CBasePlayer* pPlayer = (CBasePlayer*)matches.GetMatch(x)->GetUnknown()->GetBaseEntity();
		int iPlayer = m_Engine->IndexOfEdict( m_GameEnts->BaseEntityToEdict( pPlayer ) );
		if ( !g_Players[iPlayer].isZombie )
		{
			g_ZombiePlugin.MakeZombie( pPlayer, zombie_health.GetInt() ); // this command changes the argv/argc so we can't get the command name from it
			//print(pEdict, "nm_zombie_player: %s is now a zombie\n", /*engine->Cmd_Argv(0),*/ engine->GetClientConVarValue(pPlayer->entindex(), "name"));
			//logact(pEdict, "nm_zombie_player", "zombified %s", engine->GetClientConVarValue(pPlayer->entindex(), "name"));
			META_LOG( g_PLAPI, "%s is now a zombie.", m_Engine->GetClientConVarValue( iPlayer, "name") );
		}
	}
	return;
}

CON_COMMAND( zombie_mode, "- Toggles zombie mode" )
{
	if ( m_Engine->Cmd_Argc() == 1 )
	{
 		META_LOG( g_PLAPI, "Zombie Mode is currently %s.", ( zombie_enabled.GetBool() ? "enabled" : "disabled" ) );
		return;
	}
	if ( FStrEq( m_Engine->Cmd_Argv(1), "1" ) )
	{
		if ( !zombie_enabled.GetBool() )
		{
			g_ZombiePlugin.Hud_Print( NULL, "Zombie mode enabled." );
			g_ZombiePlugin.ZombieOn();
		}
		else
		{
			META_LOG( g_PLAPI, "Zombie Mod is already enabled." );
		}
	}
	else if ( FStrEq( m_Engine->Cmd_Argv(1), "0" ) )
	{
		if ( zombie_enabled.GetBool() )
		{
			g_ZombiePlugin.Hud_Print( NULL, "Zombie mode disabled." );
			g_ZombiePlugin.ZombieOff();
		}
		else
		{
			META_LOG( g_PLAPI, "Zombie Mod is already disabled." );
		}
	}
	else
	{
		META_LOG( g_PLAPI, "Usage: zombie_mode 1/0 Enable or disable Zombie Mod." );
	}
    return;
}

CON_COMMAND( zombie_test, "" )
{
	CBaseEntity *cBase;
	int x;
	for( x = 0; x <= MAX_PLAYERS; x++ )
	{
		if ( IsValidPlayer( x, &cBase ) )
		{
			edict_t *cEnt = m_GameEnts->BaseEntityToEdict( cBase );
			if ( ! UTIL_SetProperty( g_ZombiePlugin.g_Offsets.m_nRenderMode, cEnt, kRenderNone, true ) )
			{
				META_CONPRINT("ERROR!!!!!!! 3\n");
			}
			else
			{
				META_CONPRINT("Success...1\n");
			}
		}
	}
	return;
}

CON_COMMAND(zombie_restrict, "<a/t/c/w> <weapon> [amount] - Restricts a weapon for all players, terrorist, counter-terrorist, or winning team. Optional last parameter is how many weapons of the type the team can hold.")
{
	g_ZombiePlugin.RestrictWeapon( m_Engine->Cmd_Argv(1), m_Engine->Cmd_Argv(2), m_Engine->Cmd_Argv(3), m_Engine->Cmd_Argv(0) );
    return;
}

CON_COMMAND( zombie_list_restrictions, "Lists all current weapon restrictions." )
{
	int x = 0;
	META_CONPRINT( "\nCurrent Weapon Restrictions\n==========================\n" );
	for ( x = 0; x < CSW_MAX; x++ )
	{
		META_CONPRINTF( "%d. %d %d\n", ( x ), g_RestrictCT[x], g_RestrictT[x] );
	}
	META_CONPRINT( "==========================\n" );
}